import streamlit as st
import os
import subprocess
import pandas as pd
import matplotlib.pyplot as plt


st.sidebar.title('Activity Recognition Using Sensor Data')
st.sidebar.info('CLICK ON THE BUTTON TO START Training or Predicting!!')

if st.sidebar.button('Start Training'):
    st.header('started')
    subprocess.call(" python train.py", shell=True)
    st.header('completed')


if st.sidebar.button('Start Prediction'):
    data = pd.read_csv('report.csv').rename(columns={"Unnamed: 0": "class"})
    data = data[['class', 'f1-score']]
    fig = plt.figure(figsize=(10, 7))
    plt.bar(data['class'], data['f1-score']*100, color='maroon',
            width=0.4)
    plt.xticks(rotation=90)
    st.pyplot(fig)